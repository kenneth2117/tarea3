package com.example.app3;

public class mascota {
    private String Nombre;
    private int Foto;
    private int cantidad_likes;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public int getFoto() {
        return Foto;
    }

    public void setFoto(int foto) {
        Foto = foto;
    }

    public int getCantidad_likes() {
        return cantidad_likes;
    }

    public void setCantidad_likes(int cantidad_likes) {
        this.cantidad_likes = cantidad_likes;
    }

    public mascota(String nombre, int foto, int cantidad_likes) {
        Nombre = nombre;
        Foto = foto;
        this.cantidad_likes = cantidad_likes;
    }
}

