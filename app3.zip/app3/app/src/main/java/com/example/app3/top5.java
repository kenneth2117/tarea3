package com.example.app3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class top5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top5);

       Bundle parametros = getIntent().getExtras();
        ArrayList lista =  parametros.getParcelableArrayList("p");


        // Ordenar mascotas
        Collections.sort(lista, new Comparator<mascota>() {
            @Override
            public int compare(mascota p1, mascota p2) {
                if( p1.getCantidad_likes() > p2.getCantidad_likes() ){
                    return 1;
                }
                if( p1.getCantidad_likes() < p2.getCantidad_likes() ){
                    return -1;
                }
                return 0;
            }
        });

    }
}