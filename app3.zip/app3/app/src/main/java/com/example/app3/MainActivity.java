package com.example.app3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<mascota> listaMascota;
    RecyclerView recy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listaMascota = new ArrayList<>();
        recy = findViewById(R.id.RV_recycler);
       // recy.setLayoutManager(new LinearLayoutManager(this));
        recy.setLayoutManager(new GridLayoutManager(this,2));
        //se le pasa la lista mascotas a la clase adaptador
        Adaptador ad = new Adaptador(datos());
        recy.setAdapter(ad);

        ImageButton ib_top = findViewById(R.id.ib_top5);
        ib_top.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(MainActivity.this,top5.class);
                intento.putExtra("p",listaMascota);
                startActivity(intento);
            }
        });
    }
    private ArrayList<mascota> datos(){

        listaMascota.add(new mascota("Scooby",R.mipmap.perro1,0));
        listaMascota.add(new mascota("Docky",R.mipmap.perro2,0));
        listaMascota.add(new mascota("sally",R.mipmap.perro3,0));
        listaMascota.add(new mascota("katy",R.mipmap.gato,0));
        listaMascota.add(new mascota("coli",R.mipmap.coala,0));
        listaMascota.add(new mascota("Rodrigo",R.mipmap.coco,0));
        return listaMascota;
    }

//    public void Ir_top5(View view) {
//        Intent intento = new Intent(MainActivity.this,top5.class);
//       intento.putExtra("p_nombre",listaMascota);
//        startActivity(intento);
//    }
}