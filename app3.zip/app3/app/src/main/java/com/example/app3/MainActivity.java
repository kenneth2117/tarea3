package com.example.app3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<mascota> listaMascota;
    RecyclerView recy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recy = (RecyclerView) findViewById(R.id.RV_recycler);
        recy.setLayoutManager(new GridLayoutManager(this,2));
        //se le pasa la lista mascotas a la clase adaptador
        Adaptador ad = new Adaptador(datos());
        recy.setAdapter(ad);
    }
    private ArrayList<mascota> datos(){
        listaMascota = new ArrayList<mascota>();
        listaMascota.add(new mascota("Scooby",R.mipmap.perro1,0));
        listaMascota.add(new mascota("Docky",R.mipmap.perro2,0));
        listaMascota.add(new mascota("sally",R.mipmap.perro3,0));
        listaMascota.add(new mascota("katy",R.mipmap.gato,0));
        listaMascota.add(new mascota("coli",R.mipmap.coala,0));
        listaMascota.add(new mascota("Rodrigo",R.mipmap.coco,0));
        return listaMascota;
    }
}