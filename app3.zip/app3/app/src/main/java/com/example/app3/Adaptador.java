package com.example.app3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder> {
    ArrayList<mascota> listaMascota;

    public Adaptador(ArrayList<mascota> listaMascota) {
        this.listaMascota = listaMascota;
    }

    @NonNull
    @Override
    public Adaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //enlaza el adaptador con la vista
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_mascotas,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Adaptador.ViewHolder holder, int position) {
        //asigna adaptador y la clasa viewholder
        final  mascota m = listaMascota.get(position);
        holder.foto.setImageResource(m.getFoto());
        holder.nombre.setText(m.getNombre());
        holder.cant_likes.setText(m.getCantidad_likes());


        holder.ib_LIke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aumenta la cantidad de likes en los datos y luego en se modifca el dato que se muestra en el textview
                m.setCantidad_likes(m.getCantidad_likes()+1);
                holder.cant_likes.setText(m.getCantidad_likes()+1);

            }
        });
    }

    @Override
    public int getItemCount() {
        return listaMascota.size();
    }

    //hace referencia a los objetos del layout
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView foto;
        TextView nombre;
        TextView cant_likes;
        ImageButton ib_LIke;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            foto = (ImageView) itemView.findViewById(R.id.img_foto);
            nombre = (TextView) itemView.findViewById(R.id.tvNombre);
            cant_likes = (TextView) itemView.findViewById(R.id.tvTotalLkes);
            ib_LIke = (ImageButton) itemView.findViewById(R.id.ib_like);
        }
    }
    private void Calcular_top5(){
        Collections.sort(listaMascota, new Comparator<mascota>() {
            @Override
            public int compare(mascota m1, mascota m2) {
                // Aqui esta el truco, ahora comparamos m2 con m1 y no al reves como antes
                return new Integer(m2.getCantidad_likes()).compareTo(new Integer(m1.getCantidad_likes()));
            }
        });
    }
}

