package com.example.app3;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static androidx.core.content.ContextCompat.startActivity;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder> {
    ArrayList<mascota> listaMascota;

    public Adaptador(ArrayList<mascota> listaMascota) {
        this.listaMascota = listaMascota;
    }

    @NonNull
    @Override
    public Adaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //enlaza el adaptador con la vista
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_mascotas,null,false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final Adaptador.ViewHolder holder, int position) {
        //asigna adaptador y la clasa viewholder
        final  mascota m = listaMascota.get(position);
        holder.foto.setImageResource(m.getFoto());
        holder.nombre.setText(m.getNombre());
        String cantidad = String.valueOf(m.getCantidad_likes());
        holder.cant_likes.setText(cantidad);


        holder.ib_LIke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aumenta la cantidad de likes en los datos y luego en se modifca el dato que se muestra en el textview
                String cantidad = String.valueOf(m.getCantidad_likes()+1);
                holder.cant_likes.setText(cantidad);
                m.setCantidad_likes(Integer.parseInt(cantidad));

            }
        });
    }

    @Override
    public int getItemCount() {
        return listaMascota.size();
    }

    //hace referencia a los objetos del layout
    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView foto;
        TextView nombre;
        TextView cant_likes;
        ImageButton ib_LIke;
        ImageView foto_estrella;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            foto =  itemView.findViewById(R.id.img_foto);
            nombre =  itemView.findViewById(R.id.tvNombre);
            cant_likes =  itemView.findViewById(R.id.tvTotalLkes);
            ib_LIke =  itemView.findViewById(R.id.ib_like);
            foto_estrella = itemView.findViewById(R.id.img_star);
        }
    }


}

